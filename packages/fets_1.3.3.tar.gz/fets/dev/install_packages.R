renv::install("/Users/cassio/spec/chartsmith", prompt = FALSE)
detach("package:chartsmith", unload = TRUE)
library("chartsmith")

renv::install("/Users/cassio/spec/spectrader", prompt = FALSE)
detach("package:spectrader", unload = TRUE)
library("spectrader")
