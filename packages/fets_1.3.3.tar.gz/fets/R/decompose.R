#' Decompose data.table into metadata, targets, and features
#'
#' Splits a data.table containing symbol, date, forward-looking targets, and
#' features into three separate components for modeling.
#'
#' @param dt A data.table with symbol, date, forward method columns, and features
#' @return A list with three elements:
#'   \item{meta}{data.table with symbol and date columns}
#'   \item{y}{data.table with forward-looking target variables}
#'   \item{X}{data.table with feature columns}
#' @export
decomposeXY <- function(dtbl, inplace = FALSE, na.rm.Y = TRUE, na.rm.X = TRUE) {
  if (!data.table::is.data.table(dtbl) && !is.data.frame(dtbl)) {
    stop("dtbl must be a data.table")
  }
  if (!all(c("symbol", "date") %in% colnames(dtbl))) {
    stop("dtbl must contain 'symbol' and 'date' columns")
  }

  valid_rows <- decomposeXY.valid_rows(dtbl, na.rm.Y, na.rm.X)
  if (is.data.table(dtbl)) {
    dt <- if (inplace) { dtbl } else { data.table::copy(dtbl) }
    decomposeXY.data.table(dt, fwd_methods(), valid_rows, inplace)
  } else {
    decomposeXY.tibble(dtbl, fwd_methods(), valid_rows)
  }
}

decomposeXY.valid_rows <- function(data, na.rm.Y = TRUE, na.rm.X = TRUE) {
  if (na.rm.Y && na.rm.X) {
    complete.cases(data)
  } else if (na.rm.Y) {
    y_cols <- fwd_methods()
    complete.cases(if (is.data.table(data)) data[, ..y_cols] else data[, y_cols])
  } else if (na.rm.X) {
    x_cols <- setdiff(colnames(data), c("symbol", "date", fwd_methods()))
    complete.cases(if (is.data.table(data)) data[, ..x_cols] else data[, x_cols])
  } else {
    rep(TRUE, nrow(data))
  }
}

#' Helper function to decompose data.table
#'
#' @param dt A data.table
#' @param methods Forward method column names
#' @param valid_rows Logical vector indicating which rows to keep
#' @param inplace Whether to modify in place
#' @return A list with meta, Y, and X components
#' @keywords internal
decomposeXY.data.table <- function(dt, methods, valid_rows, inplace) {
  # Decompose dt into X, y, meta with subsetting applied
  meta <- dt[valid_rows, .(symbol, date)]
  Y <- dt[valid_rows, ..methods]
  dt[, (methods) := NULL]
  dt[, (c("symbol", "date")) := NULL]
  X <- dt[valid_rows]

  list(meta = meta, Y = Y, X = X)
}

#' Helper function to decompose tibble/data.frame
#'
#' @param dtbl A data.frame or tibble
#' @param methods Forward method column names
#' @param valid_rows Logical vector indicating which rows to keep
#' @return A list with meta, Y, and X components
#' @keywords internal
decomposeXY.tibble <- function(dtbl, methods, valid_rows) {
  meta <- dtbl[valid_rows, c("symbol", "date")]
  Y <- dtbl[valid_rows, methods]
  X <- dtbl[valid_rows, !(colnames(dtbl) %in% c("symbol", "date", methods))]

  list(meta = meta, Y = Y, X = X)
}
