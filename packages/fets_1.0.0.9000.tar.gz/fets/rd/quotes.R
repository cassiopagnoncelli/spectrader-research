devtools::load_all(".")

fetl <- Fetl$new()

vix <- fetl %>% get_vix()
quotes <- fetl %>% get_quotes()

fwd(quotes, inplace = TRUE)
add_vix(quotes, vix)

q <- fe(quotes, inplace = FALSE)

print(object.size(quotes), units = "auto")
print(object.size(q), units = "auto")

q[, .SD, .SDcols = !fwd_methods()] %>% na.omit %>% glimpse

q[symbol == symbol[1], .SD, .SDcols = !fwd_methods()][
  c(1:30, seq(.N - 20, .N))
] %>% na.omit %>% glimpse
