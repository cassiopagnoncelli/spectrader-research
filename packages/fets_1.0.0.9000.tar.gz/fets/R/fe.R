#' Feature engineering for financial time series
#'
#' Applies comprehensive feature engineering including returns, volatility, technical indicators, 
#' entropy, moments, wavelets, and autoencoder-based features.
#'
#' @param dtbl A data.table with columns: symbol, date, close
#' @param params List of parameters for feature calculations (default: list())
#' @param inplace Logical, modify data.table in place (default: FALSE)
#' @param time Logical, print total elapsed time (default: TRUE)
#' @param time_sub Logical, print elapsed time for sub-functions (default: TRUE)
#' @return Modified data.table with engineered features
#' @export
fe <- function(dtbl, params = list(), inplace = FALSE, time = TRUE, time_sub = TRUE) {
  if (!is.data.table(dtbl)) {
    stop("Input dt must be a data.table")
  }
  if (length(setdiff(c("symbol", "date", "close"), names(dtbl))) > 0) {
    stop("Data table must contain 'symbol', 'date', 'close' columns.")
  }

  start_time <- Sys.time()

  # Edit in place or create a copy
  dt <- if (inplace) { dtbl } else { data.table::copy(dtbl) }

  #
  # Feature engineering
  #
  fe_R(dt, lags = params$R_lags %||% 3, time = time_sub) # .2s
  fe_r(dt, lags = params$r_lags %||% 3, time = time_sub) # .5s

  # Moments: kurtosis, skewness
  fe_moments(
    dt,
    n = params$moments_n %||% 20,
    lags = params$moments_lags %||% 3,
    time = time_sub
  ) # 1s

  # Information
  fe_entropy(
    dt,
    n_fast = params$entropy_n_fast %||% 8,
    n_slow = params$entropy_n_slow %||% 30,
    n_bins = params$entropy_n_bins %||% 10,
    lags = params$entropy_lags %||% 3,
    time = time_sub
  ) # 5s

  # Volatility
  fe_vol(dt, n = params$vol_n %||% 20, lags = params$vol_lags %||% 3, time = time_sub) # 0.5s
  fe_vix(dt, lags = params$vix_lags %||% 3, time = time_sub) # 1s

  # Technical
  fe_rsi(dt, n = params$rsi_n %||% 14, lags = params$rsi_lags %||% 3, time = time_sub) # 2s
  fe_ema(
    dt,
    n_signal = params$n_signal %||% 3,
    n_fast = params$n_fast %||% 12,
    n_slow = params$n_slow %||% 26,
    n_macro = params$n_macro %||% 80,
    time = time_sub
  ) # 3s
  fe_ratios(
    dt,
    lags = params$ratios_lags %||% 3,
    time = time_sub
  ) # 1s

  # Wavelets
  fe_wavelets(
    dt,
    n = params$wavelets_n %||% 100,
    lags = params$wavelets_lags %||% 3,
    time = time_sub
  )

  # Autoencoder
  fe_autoencoder(
    dt,
    n = params$autoencoder_n %||% 100,
    lags = params$autoencoder_lags %||% 3,
    time = time_sub
  )

  # Clean up.
  dt[, c(
    "R_0", "r_0",
    "kurtosis_0", "skewness_0",
    "H_0", "H_slow_0",
    "vol_0",
    "vol_vix_0", "vix_0",
    "rsi_0",
    "signal_0", "fast_0", "slow_0", "macro_0",
    "signal_fast_ratio_0", "fast_slow_ratio_0", "signal_macro_ratio_0",
    "wh_0",
    "ae_recon_error_0", "ae_volatility_0"
  ) := NULL]

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("fe completed in %f seconds", elapsed))
  }

  dt
}

#' Add lag, velocity, and acceleration features
#'
#' Creates lagged versions of a feature plus velocity (first derivative) and 
#' acceleration (second derivative) features.
#'
#' @param dt Data.table to modify
#' @param feature_base Base name of the feature column
#' @param lags Integer number of lags to create (default: 2)
add_lag_vel_accel <- function(dt, feature_base, lags = 2) {
  if (lags < 1) {
    stop("Invalid parameters for lags")
  }
  # Create lagged features
  lag_seq <- seq_len(lags) - 1
  for (lag in lag_seq) {
    dt[, paste0(feature_base, "_", lag) := data.table::shift(get(feature_base), n = lag, type = "lag"), by = symbol]
  }
  # Velocity
  for (lag in head(lag_seq, -1)) {
    dt[,
      paste0(feature_base, "_vel_", lag) := 
        get(paste0(feature_base, "_", lag)) - get(paste0(feature_base, "_", lag + 1)),
      by = symbol
    ]
  }
  # Acceleration
  for (lag in head(lag_seq, -2)) {
    dt[,
      paste0(feature_base, "_accel_", lag) := 
        get(paste0(feature_base, "_vel_", lag)) - get(paste0(feature_base, "_vel_", lag + 1)),
      by = symbol
    ]
  }

  # dt[, paste0(feature_base, "_0") := NULL] # Optionally remove original feature
}

#' Simple returns feature
#'
#' Calculates simple returns (R = price_t / price_t-1 - 1).
#'
#' @param dt Data.table with close prices
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
fe_R <- function(dt, lags = 3, time = FALSE) {
  start_time <- Sys.time()

  dt[, R := close / data.table::shift(close, n = 1, type = "lag") - 1, by = symbol]

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_R: %f seconds", elapsed))
  }

  # Add lag, velocity, acceleration features
  if (lags > 0) {
    add_lag_vel_accel(dt, "R", lags = lags)
  }
}

#' Log returns feature
#'
#' Calculates log returns (r = log(1 + R)).
#'
#' @param dt Data.table with returns (R column required)
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
fe_r <- function(dt, lags = 3, time = FALSE) {
  start_time <- Sys.time()

  dt[, r := log(1 + R), by = symbol]

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_r: %f seconds", elapsed))
  }

  # Add lag, velocity, acceleration features
  if (lags > 0) {
    add_lag_vel_accel(dt, "r", lags = lags)
  }
}
#' Relative Strength Index (RSI) feature
#'
#' Calculates RSI using Wilder's smoothing method.
#'
#' @param dt Data.table with returns (R column required)
#' @param n Integer window size for RSI calculation (default: 14)
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
fe_rsi <- function(dt, n = 14, lags = 3, time = FALSE) { # Bench: 2 secs.
  start_time <- Sys.time()

  # Calculate gains and losses
  dt[, `:=`(
    gain = pmax(R, 0),
    loss = pmax(-R, 0)
  ), by = symbol]

  # Initialize with SMA for first n periods
  dt[, `:=`(
    avg_gain = data.table::frollmean(gain, n = n, align = "right", fill = NA),
    avg_loss = data.table::frollmean(loss, n = n, align = "right", fill = NA)
  ), by = symbol]

  # Apply Wilder's smoothing: avg[t] = (avg[t-1] * (n-1) + value[t]) / n
  # This is equivalent to EMA with alpha = 1/n
  dt[, `:=`(
    avg_gain = {
      ag <- avg_gain
      for (i in (n + 1):.N) {
        if (!is.na(ag[i - 1])) {
          ag[i] <- (ag[i - 1] * (n - 1) + gain[i]) / n
        }
      }
      ag
    },
    avg_loss = {
      al <- avg_loss
      for (i in (n + 1):.N) {
        if (!is.na(al[i - 1])) {
          al[i] <- (al[i - 1] * (n - 1) + loss[i]) / n
        }
      }
      al
    }
  ), by = symbol]

  # Calculate RSI
  dt[, rsi := fifelse(
    avg_loss == 0, 100,
    fifelse(
      avg_gain == 0, 0,
      100 - (100 / (1 + (avg_gain / avg_loss)))
    )
  ), by = symbol]

  # Clean up temporary columns
  dt[, c("gain", "loss", "avg_gain", "avg_loss") := NULL]

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_rsi: %f seconds", elapsed))
  }

  # Add lag, velocity, acceleration features
  if (lags > 0) {
    add_lag_vel_accel(dt, "rsi", lags = lags)
  }
}

#' Volatility feature
#'
#' Calculates rolling standard deviation of log returns.
#'
#' @param dt Data.table with log returns (r column required)
#' @param n Integer window size for volatility (default: 20)
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
fe_vol <- function(dt, n = 20, lags = 3, time = FALSE) {
  start_time <- Sys.time()

  dt[, vol := data.table::frollsd(r, n = n, align = "right", fill = NA), by = symbol]

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_vol: %f seconds", elapsed))
  }

  # Add lag, velocity, acceleration features
  if (lags > 0) {
    add_lag_vel_accel(dt, "vol", lags = lags)
  }
}

#' Exponential Moving Average (EMA) features
#'
#' Calculates multiple EMAs at different time scales (signal, fast, slow, macro).
#'
#' @param dt Data.table with close prices
#' @param n_signal Integer window for signal EMA (default: 3)
#' @param n_fast Integer window for fast EMA (default: 12)
#' @param n_slow Integer window for slow EMA (default: 26)
#' @param n_macro Integer window for macro EMA (default: 80)
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
fe_ema <- function(dt, n_signal = 3, n_fast = 12, n_slow = 26, n_macro = 80, lags = 3, time = FALSE) {
  start_time <- Sys.time()

  # Helper function to calculate EMA using native operations
  calc_ema <- function(x, n) {
    alpha <- 2 / (n + 1)
    ema <- rep(NA_real_, length(x))
    
    # Initialize with first non-NA value
    first_valid <- which(!is.na(x))[1]
    if (is.na(first_valid)) return(ema)
    
    ema[first_valid] <- x[first_valid]
    
    # Calculate EMA iteratively: EMA[t] = alpha * x[t] + (1 - alpha) * EMA[t-1]
    for (i in (first_valid + 1):length(x)) {
      if (!is.na(x[i])) {
        ema[i] <- alpha * x[i] + (1 - alpha) * ema[i - 1]
      } else {
        ema[i] <- ema[i - 1]
      }
    }
    
    ema
  }
  
  dt[, `:=`(
    signal = calc_ema(close, n_signal) / close,
    fast = calc_ema(close, n_fast) / close,
    slow = calc_ema(close, n_slow) / close,
    macro = calc_ema(close, n_macro) / close
  ), by = symbol]

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_ema: %f seconds", elapsed))
  }

  # Add lag, velocity, acceleration features
  if (lags > 0) {
    add_lag_vel_accel(dt, "signal", lags = lags)
    add_lag_vel_accel(dt, "fast", lags = lags)
    add_lag_vel_accel(dt, "slow", lags = lags)
    add_lag_vel_accel(dt, "macro", lags = lags)
  }
}

#' EMA ratio features
#'
#' Calculates ratios between different EMA time scales.
#'
#' @param dt Data.table with EMA columns (signal, fast, slow, macro required)
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
fe_ratios <- function(dt, lags = 3, time = FALSE) {
  start_time <- Sys.time()

  dt[, `:=`(
    signal_fast_ratio = signal / fast,
    fast_slow_ratio = fast / slow,
    signal_macro_ratio = signal / macro
  )]

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_ratios: %f seconds", elapsed))
  }

  # Add lag, velocity, acceleration features
  if (lags > 0) {
    add_lag_vel_accel(dt, "signal_fast_ratio", lags = lags)
    add_lag_vel_accel(dt, "fast_slow_ratio", lags = lags)
    add_lag_vel_accel(dt, "signal_macro_ratio", lags = lags)
  }
}

#' Entropy features
#'
#' Calculates rolling Shannon entropy of log returns at fast and slow scales.
#'
#' @param dt Data.table with log returns (r column required)
#' @param n_fast Integer window for fast entropy (default: 8)
#' @param n_slow Integer window for slow entropy (default: 30)
#' @param n_bins Integer number of bins for discretization (default: 10)
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
fe_entropy <- function(dt, n_fast = 8, n_slow = 30, n_bins = 10, lags = 3, time = FALSE) {
  start_time <- Sys.time()

  # Ultra-fast rolling entropy using fully vectorized operations
  calc_rolling_entropy_vectorized <- function(x, window_size, n_bins) {
    len <- length(x)
    result <- rep(NA_real_, len)
    
    # Handle edge cases
    if (all(is.na(x)) || window_size > len) return(result)
    
    # Pre-discretize the entire series once
    x_range <- range(x, na.rm = TRUE)
    if (x_range[1] == x_range[2]) {
      result[window_size:len] <- 0
      return(result)
    }
    
    # Create bins efficiently
    bins <- cut(x, breaks = n_bins, labels = FALSE, include.lowest = TRUE)
    bins[is.na(bins)] <- 0  # Handle NAs
    
    # Create cumulative count matrix for each bin (vectorized)
    cumsum_matrix <- matrix(0, nrow = len, ncol = n_bins)
    for (b in 1:n_bins) {
      cumsum_matrix[, b] <- cumsum(bins == b)
    }
    
    # Vectorized calculation of all window counts at once
    n_windows <- len - window_size + 1
    
    # Get counts for all windows using matrix operations
    # End of window counts
    end_counts <- cumsum_matrix[window_size:len, , drop = FALSE]
    
    # Start of window counts (shifted)
    start_counts <- rbind(
      matrix(0, nrow = 1, ncol = n_bins),
      cumsum_matrix[1:(len - window_size), , drop = FALSE]
    )
    
    # Window counts = end - start (fully vectorized)
    all_window_counts <- end_counts - start_counts
    
    # Vectorized entropy calculation for all windows
    # Calculate probabilities
    all_probs <- all_window_counts / window_size
    
    # Replace 0s with NA for log calculation
    all_probs[all_probs == 0] <- NA
    
    # Calculate entropy: -sum(p * log(p)) for each window
    log_probs <- log(all_probs)
    log_probs[is.na(log_probs)] <- 0  # NA * log(NA) = 0 contribution
    all_probs[is.na(all_probs)] <- 0
    
    # Vectorized entropy: sum across bins (columns) for each window (row)
    entropies <- -rowSums(all_probs * log_probs, na.rm = TRUE)
    
    # Assign results
    result[window_size:len] <- entropies
    
    result
  }
  
  dt[, H := calc_rolling_entropy_vectorized(r, n_fast, n_bins), by = symbol]
  dt[, H_slow := calc_rolling_entropy_vectorized(r, n_slow, n_bins), by = symbol]

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_entropy: %f seconds", elapsed))
  }

  # Add lag, velocity, acceleration features
  if (lags > 0) {
    add_lag_vel_accel(dt, "H", lags = lags)
    add_lag_vel_accel(dt, "H_slow", lags = lags)
  }
}

#' Statistical moments features
#'
#' Calculates rolling kurtosis and skewness of log returns.
#'
#' @param dt Data.table with log returns (r column required)
#' @param n Integer window size for moment calculation (default: 20)
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
fe_moments <- function(dt, n = 20, lags = 3, time = FALSE) {
  start_time <- Sys.time()

  # Vectorized rolling kurtosis and skewness using cumulative sums
  calc_rolling_moments_vectorized <- function(x, window_size) {
    len <- length(x)
    kurt_result <- rep(NA_real_, len)
    skew_result <- rep(NA_real_, len)
    
    if (all(is.na(x)) || window_size > len) {
      return(list(kurtosis = kurt_result, skewness = skew_result))
    }
    
    # Pre-compute powers for efficiency
    x2 <- x^2
    x3 <- x^3
    x4 <- x^4
    
    # Cumulative sums for all needed powers
    cumsum_x <- cumsum(ifelse(is.na(x), 0, x))
    cumsum_x2 <- cumsum(ifelse(is.na(x2), 0, x2))
    cumsum_x3 <- cumsum(ifelse(is.na(x3), 0, x3))
    cumsum_x4 <- cumsum(ifelse(is.na(x4), 0, x4))
    
    # Calculate for all windows using vectorized operations
    for (i in window_size:len) {
      # Get sums for current window
      if (i == window_size) {
        sum_x <- cumsum_x[i]
        sum_x2 <- cumsum_x2[i]
        sum_x3 <- cumsum_x3[i]
        sum_x4 <- cumsum_x4[i]
      } else {
        sum_x <- cumsum_x[i] - cumsum_x[i - window_size]
        sum_x2 <- cumsum_x2[i] - cumsum_x2[i - window_size]
        sum_x3 <- cumsum_x3[i] - cumsum_x3[i - window_size]
        sum_x4 <- cumsum_x4[i] - cumsum_x4[i - window_size]
      }
      
      # Calculate mean
      mean_x <- sum_x / window_size
      
      # Calculate central moments using cumulative sums
      # m2 = E[(X - mean)^2] = E[X^2] - mean^2
      m2 <- (sum_x2 / window_size) - mean_x^2
      
      # m3 = E[(X - mean)^3] = E[X^3] - 3*mean*E[X^2] + 2*mean^3
      m3 <- (sum_x3 / window_size) - 3 * mean_x * (sum_x2 / window_size) + 2 * mean_x^3
      
      # m4 = E[(X - mean)^4] = E[X^4] - 4*mean*E[X^3] + 6*mean^2*E[X^2] - 3*mean^4
      m4 <- (sum_x4 / window_size) - 4 * mean_x * (sum_x3 / window_size) + 
            6 * mean_x^2 * (sum_x2 / window_size) - 3 * mean_x^4
      
      # Calculate kurtosis and skewness
      if (m2 > 0) {
        skew_result[i] <- m3 / (m2^(3/2))
        kurt_result[i] <- m4 / (m2^2)
      }
    }
    
    list(kurtosis = kurt_result, skewness = skew_result)
  }
  
  moments <- dt[, calc_rolling_moments_vectorized(r, n), by = symbol]
  dt[, `:=`(
    kurtosis = moments$kurtosis,
    skewness = moments$skewness
  )]

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_moments: %f seconds", elapsed))
  }

  # Add lag, velocity, acceleration features
  if (lags > 0) {
    add_lag_vel_accel(dt, "kurtosis", lags = lags)
    add_lag_vel_accel(dt, "skewness", lags = lags)
  }
}

#' Hurst exponent feature (deprecated)
#'
#' Calculates rolling Hurst exponent using R/S analysis. Deprecated in favor of wavelets.
#'
#' @param dt Data.table with log returns (r column required)
#' @param n Integer window size for Hurst calculation (default: 100)
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
# Deprecated in favour of wavelets
fe_hurst <- function(dt, n = 100, lags = 3, time = FALSE) {
  start_time <- Sys.time()
  
  # Vectorized rolling Hurst exponent using R/S analysis
  calc_rolling_hurst_vectorized <- function(x, window_size) {
    len <- length(x)
    result <- rep(NA_real_, len)
    
    if (all(is.na(x)) || window_size > len || window_size < 20) return(result)
    
    # Pre-compute cumulative sums for efficiency
    cumsum_x <- cumsum(ifelse(is.na(x), 0, x))
    cumsum_x2 <- cumsum(ifelse(is.na(x^2), 0, x^2))
    
    # Sub-window sizes for R/S analysis (logarithmic spacing)
    min_size <- max(8, floor(window_size / 16))
    max_size <- floor(window_size / 2)
    if (max_size < min_size) return(result)
    
    sub_sizes <- unique(floor(exp(seq(log(min_size), log(max_size), length.out = 6))))
    
    # Calculate Hurst for each rolling window
    for (i in window_size:len) {
      # Window start index
      win_start <- i - window_size + 1
      
      # Calculate R/S for each sub-window size (vectorized)
      rs_values <- numeric(length(sub_sizes))
      
      for (j in seq_along(sub_sizes)) {
        sub_n <- sub_sizes[j]
        n_chunks <- floor(window_size / sub_n)
        
        if (n_chunks < 2) next
        
        # Vectorized R/S calculation for all chunks
        chunk_rs <- numeric(n_chunks)
        
        for (k in 1:n_chunks) {
          chunk_start <- win_start + (k - 1) * sub_n
          chunk_end <- chunk_start + sub_n - 1
          
          # Chunk data
          chunk_data <- x[chunk_start:chunk_end]
          if (all(is.na(chunk_data))) next
          
          # Chunk mean and sd using cumsum trick
          chunk_sum <- sum(chunk_data, na.rm = TRUE)
          chunk_sum2 <- sum(chunk_data^2, na.rm = TRUE)
          chunk_mean <- chunk_sum / sub_n
          chunk_sd <- sqrt((chunk_sum2 / sub_n) - chunk_mean^2)
          
          if (chunk_sd > 0) {
            # Cumulative deviation from mean
            cum_dev <- cumsum(chunk_data - chunk_mean)
            # Range
            R <- max(cum_dev, na.rm = TRUE) - min(cum_dev, na.rm = TRUE)
            # R/S
            chunk_rs[k] <- R / chunk_sd
          }
        }
        
        rs_values[j] <- mean(chunk_rs[chunk_rs > 0], na.rm = TRUE)
      }
      
      # Linear regression: log(R/S) ~ log(size) to get Hurst
      valid_idx <- !is.na(rs_values) & rs_values > 0 & is.finite(rs_values)
      if (sum(valid_idx) >= 3) {
        log_sizes <- log(sub_sizes[valid_idx])
        log_rs <- log(rs_values[valid_idx])
        
        # Fast linear regression using vectorized operations
        n_points <- length(log_sizes)
        sum_x <- sum(log_sizes)
        sum_y <- sum(log_rs)
        sum_xy <- sum(log_sizes * log_rs)
        sum_x2 <- sum(log_sizes^2)
        
        denom <- n_points * sum_x2 - sum_x^2
        if (abs(denom) > 1e-10) {
          slope <- (n_points * sum_xy - sum_x * sum_y) / denom
          result[i] <- slope  # Hurst exponent
        }
      }
    }
    
    result
  }
  
  dt[, hurst := calc_rolling_hurst_vectorized(r, n), by = symbol]
  
  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_hurst: %f seconds", elapsed))
  }
  
  if (lags > 0) {
    add_lag_vel_accel(dt, "hurst", lags = lags)
  }
}

#' Wavelet-based Hurst exponent feature
#'
#' Fast Hurst exponent estimation using rolling standard deviations at multiple scales.
#'
#' @param dt Data.table with log returns (r column required)
#' @param n Integer window size for wavelet analysis (default: 100)
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
fe_wavelets <- function(dt, n = 100, lags = 3, time = FALSE) {
  start_time <- Sys.time()
  
  # Ultra-fast wavelet-based Hurst using data.table's froll* operations
  # Simplified approach: use rolling standard deviations at multiple scales
  # For fBm: sd(scale) ∝ scale^H, so log(sd) = H*log(scale) + c
  
  # Define scales (powers of 2 for efficiency)
  max_scale <- floor(n / 4)
  scales <- unique(c(4, 8, 16, 32, 64, min(128, max_scale)))
  scales <- scales[scales <= max_scale]
  
  if (length(scales) < 3) {
    dt[, wavelet_H := NA_real_]
    if (time) {
      message("  fe_wavelets: window too small for wavelet analysis")
    }
    return()
  }
  
  # Calculate rolling std dev at each scale using frollsd (blazing fast!)
  scale_sds <- lapply(scales, function(scale) {
    dt[, data.table::frollsd(r, n = scale, align = "right", fill = NA), by = symbol]
  })
  
  # Combine into matrix (each column is a scale)
  sd_matrix <- do.call(cbind, lapply(scale_sds, function(x) x$V1))
  
  # Vectorized Hurst calculation for all positions at once
  log_scales <- log2(scales)
  
  # For each row (time point), fit log(sd) ~ log(scale) to get H
  dt[, wh := {
    result <- rep(NA_real_, .N)
    
    for (i in seq_len(.N)) {
      sds <- sd_matrix[i, ]
      valid <- !is.na(sds) & sds > 0 & is.finite(sds)
      
      if (sum(valid) >= 3) {
        log_sds <- log2(sds[valid])
        log_sc <- log_scales[valid]
        
        # Fast linear regression
        n_pts <- length(log_sc)
        sum_x <- sum(log_sc)
        sum_y <- sum(log_sds)
        sum_xy <- sum(log_sc * log_sds)
        sum_x2 <- sum(log_sc^2)
        
        denom <- n_pts * sum_x2 - sum_x^2
        if (abs(denom) > 1e-10) {
          result[i] <- (n_pts * sum_xy - sum_x * sum_y) / denom
        }
      }
    }
    result
  }, by = symbol]
  
  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_wavelets: %f seconds", elapsed))
  }
  
  if (lags > 0) {
    add_lag_vel_accel(dt, "wh", lags = lags)
  }
}

#' VIX ratio feature
#'
#' Calculates ratio of realized volatility to VIX.
#'
#' @param dt Data.table with vol and vix columns
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
fe_vix <- function(dt, lags = 3, time = FALSE) {
  start_time <- Sys.time()

  dt[, vol_vix := vol / vix, by = symbol]

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_vix: %f seconds", elapsed))
  }

  # Add lag, velocity, acceleration features
  if (lags > 0) {
    add_lag_vel_accel(dt, "vol_vix", lags = lags)
    add_lag_vel_accel(dt, "vix", lags = lags)
  }
}

#' Autoencoder-inspired reconstruction features
#'
#' Fast anomaly detection using reconstruction error from rolling statistics.
#'
#' @param dt Data.table with multiple feature columns
#' @param n Integer window size for reconstruction (default: 100)
#' @param lags Integer number of lags for derivatives (default: 3)
#' @param time Logical, print elapsed time (default: FALSE)
fe_autoencoder <- function(dt, n = 100, lags = 3, time = FALSE) {
  start_time <- Sys.time()

  # Blazing fast autoencoder-inspired feature using froll* operations
  # This captures anomalies and compression quality similar to an autoencoder
  # but runs in milliseconds using data.table's C-optimized functions
  
  # Select key features to "compress" (like autoencoder input layer)
  feature_cols <- c("r", "vol", "rsi", "H", "wh")
  available_cols <- feature_cols[feature_cols %in% names(dt)]
  
  if (length(available_cols) < 2) {
    dt[, ae_recon_error := NA_real_]
    if (time) {
      message("  fe_autoencoder: insufficient features for reconstruction")
    }
    return()
  }
  
  # Compute rolling means and sds for ALL features at once (blazing fast!)
  rolling_means <- lapply(available_cols, function(col) {
    dt[, data.table::frollmean(get(col), n = n, align = "right", fill = NA), by = symbol]$V1
  })
  
  rolling_sds <- lapply(available_cols, function(col) {
    dt[, data.table::frollsd(get(col), n = n, align = "right", fill = NA), by = symbol]$V1
  })
  
  # Combine into matrices for vectorized operations
  mean_matrix <- do.call(cbind, rolling_means)
  sd_matrix <- do.call(cbind, rolling_sds)
  
  # Get current values matrix
  current_matrix <- as.matrix(dt[, ..available_cols])
  
  # Vectorized reconstruction error calculation
  # Normalized distance from rolling mean (fully vectorized!)
  normalized_diff <- (current_matrix - mean_matrix) / (sd_matrix + 1e-10)
  
  # Euclidean distance across features (rowMeans of squared differences)
  dt[, ae_recon_error := sqrt(rowMeans(normalized_diff^2, na.rm = TRUE))]
  
  # Add rolling variance of reconstruction error (captures instability)
  dt[, ae_volatility := data.table::frollsd(ae_recon_error, n = 20, 
                                            align = "right", fill = NA), by = symbol]
  
  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("  fe_autoencoder: %f seconds", elapsed))
  }

  # Add lag, velocity, acceleration features
  if (lags > 0) {
    add_lag_vel_accel(dt, "ae_recon_error", lags = lags)
    add_lag_vel_accel(dt, "ae_volatility", lags = lags)
  }
}
