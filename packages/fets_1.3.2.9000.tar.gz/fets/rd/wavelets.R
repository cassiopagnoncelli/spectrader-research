library("ggplot2")
library("wavelets")
library("zoo")

rolling_hurst <- function(r, window = 100) {
  r <- r[is.finite(r)]
  r <- r - mean(r)

  rollapplyr(
    data = r,
    width = window,
    by = 1,
    fill = NA,
    align = "right",
    FUN = function(x) {
      wt <- dwt(x, filter = "haar", boundary = "periodic")
      levels <- length(wt@W)
      scales <- 2^(1:levels)
      vars <- sapply(wt@W, function(w) var(w, na.rm = TRUE))
      fit <- lm(log2(vars) ~ log2(scales))
      (coef(fit)[2] - 1) / 2  # return H
    }
  )
}

sym <- "A"

df <- q[symbol == sym, .(date, r, hurst)] %>% tibble()
r <- df$r

H_roll <- rolling_hurst(r, window = 100)
df$H_roll <- c(NA, H_roll)

df <- df %>% dplyr::mutate(
  hs = scale(hurst),
  ws = scale(H_roll)
)

df %>% summary
df %>%
  ggplot(aes(x = date, y = hs)) +
  geom_line(linewidth = 1.2) +
  geom_line(aes(x = date, y = ws), color = "red", linewidth = 0.5) +
  labs(
    title = paste("Rolling Hurst Exponent for", sym),
    y = "Hurst Exponent (Scaled)",
    x = "Date"
  ) +
  theme_minimal()

x <- q[symbol == "A", .(date, he = scale(hurst))]
x %>% summary
log(1 + x$he) %>% na.omit %>% MASS::truehist(nbins = 100)
x$he.V1 %>% na.omit %>% plot(t='l', col='red')

r <- na.omit(q[symbol == "A", .(r)]$r)
