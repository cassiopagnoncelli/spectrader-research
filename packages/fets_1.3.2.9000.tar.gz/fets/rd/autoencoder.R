# ============================================
# Rolling Autoencoder Features — Univariate + Multivariate
# ============================================

library(data.table)
library(keras)

# --- Example data -------------------------------------------------------------
set.seed(1)
dates <- seq.Date(as.Date("2020-01-01"), by = "days", length.out = 800)
dt <- data.table(
  date = dates,
  AAPL = rnorm(800, 0, 0.015),
  MSFT = rnorm(800, 0, 0.013),
  NVDA = rnorm(800, 0, 0.02)
)

# normalize
cols <- c("AAPL", "MSFT", "NVDA")
dt[, (cols) := lapply(.SD, scale), .SDcols = cols]

# --- Function: Rolling autoencoder embeddings --------------------------------
rolling_autoencoder <- function(X, window = 200, latent_dim = 3, epochs = 40) {
  latent_list <- list()
  n <- nrow(X)

  for (i in seq(window, n)) {
    x <- as.matrix(X[(i - window + 1):i, ])
    input_dim <- ncol(x)

    input_layer <- layer_input(shape = input_dim)
    encoded <- input_layer %>%
      layer_dense(units = 32, activation = "relu") %>%
      layer_dense(units = latent_dim, activation = "linear")
    decoded <- encoded %>%
      layer_dense(units = 32, activation = "relu") %>%
      layer_dense(units = input_dim, activation = "linear")

    ae <- keras_model(input_layer, decoded)
    encoder <- keras_model(input_layer, encoded)

    ae %>% compile(optimizer = "adam", loss = "mse")
    ae %>% fit(x, x, epochs = epochs, verbose = 0)

    latent_list[[i]] <- predict(encoder, x[nrow(x), , drop = FALSE])
  }

  z <- do.call(rbind, latent_list)
  colnames(z) <- paste0("latent_", seq_len(ncol(z)))
  z
}

# --- 1) Univariate rolling embeddings (AAPL only) -----------------------------
latent_uni <- rolling_autoencoder(dt[, .(AAPL)], window = 200, latent_dim = 2)
latent_uni <- data.table(date = dt$date[200:nrow(dt)], latent_uni)
setnames(latent_uni, c("date", "z1", "z2"))

# --- 2) Multivariate rolling embeddings (AAPL, MSFT, NVDA) -------------------
latent_multi <- rolling_autoencoder(dt[, ..cols], window = 200, latent_dim = 3)
latent_multi <- data.table(date = dt$date[200:nrow(dt)], latent_multi)
setnames(latent_multi, c("date", "z1", "z2", "z3"))

# --- Merge results ------------------------------------------------------------
features <- merge(latent_uni, latent_multi, by = "date", suffixes = c("_uni", "_multi"))
print(head(features))
