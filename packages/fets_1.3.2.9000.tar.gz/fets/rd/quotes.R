devtools::load_all(".")

# ETL
fetl <- Fetl$new()

vix <- fetl %>% get_vix()
quotes <- fetl %>% get_quotes()
add_vix(quotes, vix)

# Calculate forwards
fwd(quotes, inplace = TRUE)

# Feature Engineering
qf <- fe(quotes, inplace = FALSE)
qf$new_features
q <- qf$X %>% na.omit

# View data
print(object.size(quotes), units = "auto")
print(object.size(q), units = "auto")

q[, .SD, .SDcols = fwd_methods()] %>% glimpse
q[, .SD, .SDcols = !fwd_methods()] %>% glimpse

q[symbol == symbol[1], .SD, .SDcols = !fwd_methods()][
  c(1:30, seq(.N - 20, .N))
] %>% na.omit %>% glimpse

# Decompose
qt <- tibble::tibble(q)
decomposed <- decomposeXY(qt, na.rm.X = TRUE, na.rm.Y = TRUE)
