devtools::load_all(".")

fetl <- Fetl$new()

vix <- fetl %>% get_vix()
quotes <- fetl %>% get_quotes()
add_vix(quotes, vix)

fwd(quotes, inplace = TRUE)

qf <- fe(quotes, inplace = FALSE)
qf$new_features
q <- qf$X %>% na.omit

print(object.size(quotes), units = "auto")
print(object.size(q), units = "auto")

q[, .SD, .SDcols = fwd_methods()] %>% glimpse
q[, .SD, .SDcols = !fwd_methods()] %>% glimpse

q[symbol == symbol[1], .SD, .SDcols = !fwd_methods()][
  c(1:30, seq(.N - 20, .N))
] %>% na.omit %>% glimpse
