## Dependencies

Data Table requires OpenMP, so you have to install it and then manually
compile and install the package from R

```sh
brew install llvm libomp
```

```r
install.packages("data.table", type = "source",
                 configure.args="--enable-openmp")
```

You may check for multithreading

```r
> getDTthreads(verbose = TRUE)
This installation of data.table has not been compiled with OpenMP support.
  omp_get_num_procs()            1
  R_DATATABLE_NUM_PROCS_PERCENT  unset (default 50)
  R_DATATABLE_NUM_THREADS        unset
  R_DATATABLE_THROTTLE           unset (default 1024)
  omp_get_thread_limit()         1
  omp_get_max_threads()          1
  OMP_THREAD_LIMIT               unset
  OMP_NUM_THREADS                unset
  RestoreAfterFork               true
  data.table is using 1 threads with throttle==1024. See ?setDTthreads.
[1] 1
```

Besides, .Renvion was customised to use homebrew's OpenMP-enabled C compiler,
since Apple Silicon won't support OpenMP.

```r
Sys.setenv(R_INSTALL_STAGED = "false")
Sys.setenv(DYLD_LIBRARY_PATH="/opt/homebrew/opt/libomp/lib")

install.packages("data.table", type = "source", INSTALL_opts = "--no-test-load")
```

or 

```r
install.packages("data.table")

# latest development version (only if newer available)
data.table::update_dev_pkg()

# latest development version (force install)
install.packages("data.table", repos="https://rdatatable.gitlab.io/data.table")
```
