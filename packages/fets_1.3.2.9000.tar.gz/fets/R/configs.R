# Configure timezone settings
Sys.setenv(TZ = "UTC")

# Optionally, if you want to disable the timezone check warning
options(xts_check_TZ = FALSE)
