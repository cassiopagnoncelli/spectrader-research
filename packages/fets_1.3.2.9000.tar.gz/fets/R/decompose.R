#' Decompose data.table into metadata, targets, and features
#'
#' Splits a data.table containing symbol, date, forward-looking targets, and
#' features into three separate components for modeling.
#'
#' @param dt A data.table with symbol, date, forward method columns, and features
#' @return A list with three elements:
#'   \item{meta}{data.table with symbol and date columns}
#'   \item{y}{data.table with forward-looking target variables}
#'   \item{X}{data.table with feature columns}
#' @export
decomposeXy <- function(dtbl, inplace = FALSE, na.rm = TRUE) {
  if (!data.table::is.data.table(dtbl)) {
    stop("dtbl must be a data.table")
  }
  if (!all(c("symbol", "date") %in% colnames(dtbl))) {
    stop("dtbl must contain 'symbol' and 'date' columns")
  }

  # Copy dtbl if not inplace
  dt <- if (inplace) { dtbl } else { data.table::copy(dtbl) }

  # Decompose dt into X, y, meta
  methods <- fwd_methods()

  meta <- dt[, .(symbol, date)]
  y <- dt[, ..methods]
  dt[, (methods) := NULL]
  dt[, (c("symbol", "date")) := NULL]

  # Remove rows with NA in y if specified
  if (na.rm) {
    cc <- complete.cases(y)
    y <- y[cc]
    meta <- meta[cc]
    dt <- dt[cc]
  }

  list(
    meta = meta,
    y = y,
    X = dt
  )
}
