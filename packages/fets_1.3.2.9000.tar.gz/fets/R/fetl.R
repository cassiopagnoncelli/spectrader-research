if (!exists(".spectrader_env")) {
  .spectrader_env <- new.env()
  .spectrader_env$pool <- NULL
}

#' Datasource Postgres
#'
#' @description A singleton, half-duplex/simplex Postgres connector to fetch
#'  data quotes from a Postgres database.
#' @export
Fetl <- R6::R6Class( # nolint: object_name_linter
  "Fetl",
  public = list(
    # Parameters.
    pool = NULL,
    verbose = NULL,

    # Methods.
    initialize = function() {
      private$host <- private$get_var("POSTGRES_HOST", "localhost")
      private$dbname <- private$get_var("POSTGRES_DB", "fetl_development")
      private$user <- private$get_var("POSTGRES_USER", "cassio")
      private$password <- private$get_var("POSTGRES_PASSWORD", "123456")
      private$port <- private$get_var("POSTGRES_PORT", 5432)
      invisible(self)
    },
    connect = function(force_reconnect = FALSE, verbose = FALSE) {
      self$verbose <- verbose
      if (!force_reconnect && !is.null(self$pool)) {
        if (verbose) {
          message("Data source fetl already connected")
        }
        return(self$pool)
      }
      if (!force_reconnect && exists("pool", envir = .spectrader_env) &&
        !is.null(.spectrader_env$pool) &&
        inherits(.spectrader_env$pool, "Pool")) {
        self$pool <- .spectrader_env$pool
        if (verbose) {
          message("Data source fetl relinked")
        }
        return(self$pool)
      }

      if (verbose) {
        message(sprintf(
          "Data source fetl %s connecting...",
          ifelse(force_reconnect, "force", "is")
        ))
      }
      .spectrader_env$pool <- pool::dbPool(
        drv = RPostgreSQL::PostgreSQL(),
        dbname = private$dbname,
        host = private$host,
        user = private$user,
        password = private$password,
        port = private$port
      )
      if (verbose) {
        message(sprintf(
          "Data source fetl connected to database %s.",
          private$dbname
        ))
      }
      self$pool <- .spectrader_env$pool
      return(self$pool)
    },
    disconnect = function() {
      # Only close the pool once since self$pool and .spectrader_env$pool 
      # reference the same object
      pool_to_close <- NULL
      
      if (!is.null(self$pool) && inherits(self$pool, "Pool")) {
        pool_to_close <- self$pool
      } else if (exists(".spectrader_env", envir = .GlobalEnv) &&
                 !is.null(.spectrader_env$pool) &&
                 inherits(.spectrader_env$pool, "Pool")) {
        pool_to_close <- .spectrader_env$pool
      }
      
      if (!is.null(pool_to_close)) {
        tryCatch(
          {
            # Check if pool is still valid before closing
            if (pool::dbIsValid(pool_to_close)) {
              pool::poolClose(pool_to_close)
            }
          },
          error = function(e) {
            # Only warn if it's not an "already closed" error
            if (!grepl("closed", e$message, ignore.case = TRUE)) {
              warning("Error closing connection pool: ", e$message)
            }
          }
        )
      }
      
      # Clean up references
      self$pool <- NULL
      if (exists(".spectrader_env", envir = .GlobalEnv)) {
        .spectrader_env$pool <- NULL
      }
    },
    send_query = function(query, time = FALSE, verbose = FALSE, name = NULL) {
      if (is.null(self$pool)) {
        self$connect()
      }

      start_time <- Sys.time()

      if (verbose)
        message(sprintf("Executing query:\n%s", query))
      
      result <- DBI::dbGetQuery(self$pool, query)

      if (time) {
        end_time <- Sys.time()
        elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
        message(sprintf("%s completed in %f seconds", ifelse(is.null(name), "SQL", name), elapsed))
      }
      
      tibble::tibble(result)
    },
    fred_univariate = function(code, freq = NULL, from = NULL, to = NULL, time = FALSE, verbose = FALSE) {
      query <- self$build_fred_univariates_query(code, freq, from, to)
      self$send_query(query, time = time, verbose = verbose, name = code)
    },
    build_fred_univariates_query = function(code, freq, from, to) {
      if (is.null(code) || !is.character(code) || length(code) != 1) {
        stop("Parameter 'code' must be a non-empty character string.")
      }
      code_sanitized <- private$sanitize_ticker(code)
      clause_code <- sprintf("(code = '%s')", code_sanitized)
      if (!is.null(freq)) {
        if (!is.character(freq) || length(freq) != 1) {
          stop("Parameter 'freq' must be a single character string.")
        }
        freq_sanitized <- private$sanitize_ticker(freq)
        clause_freq <- sprintf("(freq = '%s')", freq_sanitized)
      } else {
        clause_freq <- NULL
      }
      if (!is.null(from)) {
        if (!grepl("^\\d{4}-\\d{2}-\\d{2}$", from)) {
          stop("from must be in 'YYYY-MM-DD' format.")
        }
        clause_from <- sprintf("(date >= '%s'::DATE)", from)
      } else {
        clause_from <- NULL
      }
      if (!is.null(to)) {
        if (!grepl("^\\d{4}-\\d{2}-\\d{2}$", to)) {
          stop("to must be in 'YYYY-MM-DD' format.")
        }
        clause_to <- sprintf("(date <= '%s'::DATE)", to)
      } else {
        clause_to <- NULL
      }
      clauses_vec <- c(
        clause_code,
        clause_freq,
        clause_from,
        clause_to
      )
      clauses_nonempty <- clauses_vec[!is.null(clauses_vec) & clauses_vec != ""]
      clauses <- paste(clauses_nonempty, collapse = " AND ")
      private$sanitize_sql(sprintf("
        SELECT
          code, freq, date, value
        FROM fred_univariates
        WHERE %s
        ORDER BY date ASC
      ", clauses))
    }
  ),
  private = list(
    # Credentials.
    host = NULL,
    dbname = NULL,
    user = NULL,
    password = NULL,
    port = NULL,

    # Methods.
    sanitize_sql = function(str) {
      q <- gsub("\n", " ", str)
      q <- gsub("\\s+", " ", q)
      q <- trimws(q)
      q
    },
    sanitize_ticker = function(symbol) {
      q <- gsub("\\s+", "", symbol)
      q
    },
    get_var = function(env_name, default) {
      if (nchar(Sys.getenv(env_name)) > 0) {
        Sys.getenv(env_name)
      } else {
        default
      }
    }
  )
)

# Note: Connection pool cleanup is now handled automatically by the pool package's
# internal finalizers. Since we're using DBI::dbGetQuery() which properly manages
# connection checkout/return, we don't need explicit cleanup hooks that could
# interfere with active connections during session termination.

get_quotes <- function(fetl, num_companies = NULL, from = NULL, to = NULL, time = TRUE, verbose = FALSE) {
  from <- ifelse(is.null(from), "2021-01-01", from)
  to <- ifelse(is.null(to), as.character(Sys.Date()), to)
  companies_clause <- ifelse(is.null(num_companies), "", sprintf(", max_companies => %d", num_companies))

  fwd_sql <- sprintf("
    SELECT
      c.symbol,
      q.date,
      q.open,
      q.high,
      q.low,
      q.close
    FROM quotes q
    JOIN companies c ON q.company_id = c.id
    JOIN company_screener_ids(
      min_trade_date => '%s'::DATE,
      min_market_cap => 1.5e10,
      random_sample => TRUE
      %s
    ) c2 ON c.id = c2.id
    WHERE
      q.date BETWEEN '%s' AND '%s'
  ", from, companies_clause, from, to)

  fwd_raw <- fetl$send_query(fwd_sql, time = time, verbose = verbose, name = "quotes")

  DT <- data.table::as.data.table(fwd_raw)
  data.table::setkey(DT, symbol, date)
  DT
}

get_vix <- function(fetl, time = TRUE, verbose = FALSE) {
  vix_raw <- fetl$fred_univariate("VIXCLS", "D", time = time, verbose = verbose)

  DT <- data.table::as.data.table(vix_raw)
  data.table::setkey(DT, date)
  DT
}

add_vix <- function(dt, vix) {
  dt[
    vix[date >= min(dt$date), .(date, vix = value)],
    vix := i.vix,
    on = .(date),
    roll = TRUE
  ]
  invisible(dt)
}
