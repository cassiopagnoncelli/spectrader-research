#' Forward-looking feature calculation
#'
#' Calculates forward-looking technical indicators for financial time series data.
#'
#' @param dtbl A data.table with columns: symbol, date, open, high, low, close
#' @param methods Character vector of methods to apply (default: all available methods)
#' @param lookahead Integer number of periods to look ahead (default: 15)
#' @param drop Logical, drop OHLC columns except close (default: TRUE)
#' @param inplace Logical, modify data.table in place (default: FALSE)
#' @param time Logical, print elapsed time (default: TRUE)
#' @return Modified data.table with forward-looking features
#' @export
fwd <- function(
  dtbl,
  methods = fwd_methods(),
  lookahead = 15,
  params = list(
    signal = 5,
    short = 12,
    long = 28,
    macro = 80
  ),
  drop.ohl = TRUE,
  na.rm = TRUE,
  inplace = TRUE,
  time = TRUE
) {
  if (!is.data.table(dtbl)) {
    stop("Input dt must be a data.table")
  }
  if (length(setdiff(c("symbol", "date", "open", "high", "low", "close"), names(dtbl))) > 0) {
    stop("Data table must contain 'symbol', 'date', 'open', 'high', 'low', and 'close' columns.")
  }

  start_time <- Sys.time()

  # Edit in place or create a copy
  dt <- if (inplace) { dtbl } else { data.table::copy(dtbl) }

  # Ensure parameters
  params$signal <- params$signal %||% 5
  params$short <- params$short %||% 12
  params$long <- params$long %||% 28
  params$macro <- params$macro %||% 80

  # Calculate methods for each symbol
  apply_fwd_shared(dt, lookahead, params)
  for (method in methods) {
    method_start_time <- Sys.time()
    apply_fwd(dt, method, lookahead, params)
    if (time) {
      end_time <- Sys.time()
      elapsed <- as.numeric(difftime(end_time, method_start_time, units = "secs"))
      message(sprintf("  %s: completed in %f seconds", method, elapsed))
    }
  }
  apply_fwd_cleanup(dt)

  if (drop.ohl) {
    dt[, c("open", "high", "low") := NULL]
  }

  if (na.rm) {
    dt <- na.omit(dt)
  }

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("fwd completed in %f seconds", elapsed))
  }

  dt
}

#' Available forward-looking methods
#'
#' Returns a character vector of all available forward-looking calculation methods.
#'
#' @return Character vector of method names
#' @export
fwd_methods <- function() {
  c(
    # Modified Sharpe methods
    "pas",
    "dd_sharpe",
    "entropy_sharpe",
    # Extreme (max high, min low) methods
    "extreme_high_identity",
    "extreme_high_log",
    "extreme_low_identity",
    "extreme_low_log",
    # Mass (sum, integral) methods
    "mass_high",
    "mass_low",
    # Differentials extreme (de) and mass (dm) methods
    "de",
    "dm",
    # Moments
    "skewness",
    # Moving averages
    "ma_short_ratio",
    "ma_long_ratio",
    "ma_macro_ratio",
    # Last methods
    "close_identity",
    "close_log"
  )
}

#' Apply forward-looking method
#'
#' Dispatches to specific forward-looking calculation method.
#'
#' @param dt Data.table with OHLC data
#' @param method Character string specifying the method
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd <- function(dt, method, lookahead, params) {
  # Modified Sharpe methods
  if (method == "pas") {
    apply_fwd_pas(dt, lookahead)
  } else if (method == "dd_sharpe") {
    apply_fwd_dd_sharpe(dt, lookahead)
  } else if (method == "entropy_sharpe") {
    apply_fwd_entropy_sharpe(dt, lookahead)
  } else
  # Extreme (max high, min low) methods
  if (method == "extreme_high_identity") {
    apply_fwd_extreme_high_identity(dt, lookahead)
  } else if (method == "extreme_high_log") {
    apply_fwd_extreme_high_log(dt, lookahead)
  } else if (method == "extreme_low_identity") {
    apply_fwd_extreme_low_identity(dt, lookahead)
  } else if (method == "extreme_low_log") {
    apply_fwd_extreme_low_log(dt, lookahead)
  } else
  # Mass (sum, integral) methods
  if (method == "mass_high") {
    apply_fwd_mass_high(dt, lookahead)
  } else if (method == "mass_low") {
    apply_fwd_mass_low(dt, lookahead)
  } else
  # Differential extreme (de) and mass (dm) methods
  if (method == "de") {
    apply_fwd_de(dt, lookahead)
  } else if (method == "dm") {
    apply_fwd_dm(dt, lookahead)
  } else
  # Moments
  if (method == "skewness") {
    apply_fwd_skewness(dt, lookahead)
  } else
  # Moving averages
  if (method == "ma_short_ratio") {
    apply_fwd_ma_short_ratio(dt, lookahead, params)
  } else if (method == "ma_long_ratio") {
    apply_fwd_ma_long_ratio(dt, lookahead, params)
  } else if (method == "ma_macro_ratio") {
    apply_fwd_ma_macro_ratio(dt, lookahead, params)
  } else
  # Last methods
  if (method == "close_identity") {
    apply_fwd_close_identity(dt, lookahead)
  } else if (method == "close_log") {
    apply_fwd_close_log(dt, lookahead)
  } else {
  # Unrecognised method
    stop(sprintf("Unknown method: %s", method))
  }

  invisible(dt)
}

#' Create shared forward-looking columns
#'
#' Pre-computes commonly used shifted and rolling calculations to avoid redundant operations.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @param params List containing MA periods
#' @return Modified data.table (invisible)
apply_fwd_shared <- function(dt, lookahead, params) {
  # Shifted columns
  dt[, `:=`(
    future_high  = shift(high,  n = 1, type = "lead"),
    future_low   = shift(low,   n = 1, type = "lead"),
    future_close = shift(close, n = 1, type = "lead")
  ), by = symbol]
  
  # Rolling extremes
  dt[, `:=`(
    future_max = frollmax(future_high, n = lookahead, align = "left", na.rm = TRUE),
    future_min = frollmin(future_low,  n = lookahead, align = "left", na.rm = TRUE)
  ), by = symbol]
  
  # Returns and volatility
  dt[, `:=`(
    future_rets = future_close / close - 1
  ), by = symbol]
  
  dt[, sigma_path := frollsd(future_rets, n = lookahead, align = "left", na.rm = TRUE), by = symbol]
  
  # Midpoint and rolling sums
  dt[, `:=`(
    future_midpoint = (future_high + future_low) / 2,
    future_sum_high = frollsum(future_high, n = lookahead, align = "left", na.rm = TRUE),
    future_sum_low  = frollsum(future_low,  n = lookahead, align = "left", na.rm = TRUE)
  ), by = symbol]
  
  # Moving averages for MA methods
  dt[, future_close_shifted := shift(close, n = lookahead, type = "lead"), by = symbol]
  
  dt[, `:=`(
    future_ma_signal = frollmean(future_close_shifted, n = params$signal, align = "left", na.rm = TRUE),
    future_ma_short  = frollmean(future_close_shifted, n = params$short,  align = "left", na.rm = TRUE),
    future_ma_long   = frollmean(future_close_shifted, n = params$long,   align = "left", na.rm = TRUE),
    future_ma_macro  = frollmean(future_close_shifted, n = params$macro,  align = "left", na.rm = TRUE)
  ), by = symbol]
  
  # Rolling sums for DM methods
  dt[, `:=`(
    future_sum_high_norm = frollsum(future_high / open - 1, n = lookahead, align = "left", na.rm = TRUE),
    future_sum_low_norm = frollsum(1 - future_low / open, n = lookahead, align = "left", na.rm = TRUE)
  ), by = symbol]
  
  invisible(dt)
}

#' Clean up shared forward-looking columns
#'
#' Removes temporary columns created by apply_fwd_shared.
#'
#' @param dt Data.table with shared columns
#' @return Modified data.table (invisible)
apply_fwd_cleanup <- function(dt) {
  shared_cols <- c(
    "future_high", "future_low", "future_close",
    "future_max", "future_min",
    "future_rets", "sigma_path",
    "future_midpoint", "future_sum_high", "future_sum_low",
    "future_close_shifted",
    "future_ma_signal", "future_ma_short", "future_ma_long", "future_ma_macro",
    "future_sum_high_norm", "future_sum_low_norm"
  )
  dt[, (shared_cols) := NULL]
  invisible(dt)
}

#' Price-Adjusted Sharpe forward feature
#'
#' Calculates risk-adjusted return with customizable penalty terms for volatility, drawdown, and choppiness.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @param lambda Penalty weight for maximum adverse excursion (default: 1)
#' @param gamma Penalty weight for choppiness relative to return (default: 1)
#' @param eta Bonus weight for maximum favorable excursion (default: 0.0)
#' @param eps Small constant to prevent division by zero (default: 1e-12)
#' @return Modified data.table (invisible)
apply_fwd_pas <- function(dt, lookahead,
                          lambda = 1,
                          gamma  = 1,
                          eta    = 0.0,
                          eps    = 1e-12) {

  dt[, pas := {
    future_high  <- shift(high,  n = 1, type = "lead")
    future_low   <- shift(low,   n = 1, type = "lead")
    future_close <- shift(close, n = 1, type = "lead")

    future_max <- frollmax(future_high, n = lookahead, align = "left")
    future_min <- frollmin(future_low,  n = lookahead, align = "left")

    future_rets <- future_close / close - 1
    sigma_path  <- frollsd(future_rets, n = lookahead, align = "left", na.rm = TRUE)

    r_T  <- (future_max / close) - 1
    MAE  <- pmax(0, (close - future_min) / close)
    MFE  <- pmax(0, (future_max - close) / close)

    penalty_vol = sigma_path^2
    penalty_mae = lambda * MAE^2
    penalty_chop = gamma * (sigma_path / (abs(r_T) + eps))^2

    conform((r_T + eta * MFE) / sqrt(penalty_vol + penalty_mae + penalty_chop))
  }, by = symbol]

  invisible(dt)
}

#' Drawdown-adjusted Sharpe forward feature
#'
#' Calculates risk-adjusted return measure penalized by drawdown and volatility.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_dd_sharpe <- function(dt, lookahead) {
  dt[, dd_sharpe := {
    future_high  <- shift(high,  n = 1, type = "lead")
    future_low   <- shift(low,   n = 1, type = "lead")
    future_close <- shift(close, n = 1, type = "lead")

    future_max <- frollmax(future_high, n = lookahead, align = "left")
    future_min <- frollmin(future_low,  n = lookahead, align = "left")

    future_rets <- future_close / close - 1
    sigma_path  <- frollsd(future_rets, n = lookahead, align = "left", na.rm = TRUE)

    r_T    <- (future_max / close) - 1
    DD_max <- pmax(0, (close - future_min) / close)

    r_T / sqrt(5e-2 + sigma_path^2 + DD_max^2)
  }, by = symbol]

  invisible(dt)
}

#' Entropy-adjusted Sharpe forward feature
#'
#' Calculates risk-adjusted return penalized by volatility and path entropy.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @param eps Small constant to prevent division by zero (default: 1e-12)
#' @return Modified data.table (invisible)
apply_fwd_entropy_sharpe <- function(dt, lookahead, nbins = 32, eps = 1e-12) {

  dt[, entropy_sharpe := {
    n <- .N

    future_close <- shift(close, 1, type = "lead")
    future_rets  <- future_close / close - 1

    mx <- max(abs(future_rets), na.rm = TRUE)
    edges <- seq(-mx, mx, length.out = nbins + 1)
    bin_id <- findInterval(future_rets, edges, rightmost.closed = TRUE)

    future_high <- shift(high, 1, type = "lead")
    future_low  <- shift(low, 1, type = "lead")
    future_max  <- frollmax(future_high, n = lookahead, align = "left")
    future_min  <- frollmin(future_low,  n = lookahead, align = "left")
    sigma_path  <- frollsd(future_rets, n = lookahead, align = "left")

    ES <- rep(NA_real_, n)

    # histogram counts for window
    hist <- integer(nbins)

    # initialize first window: rows 2..(lookahead+1)
    win_start <- 1
    win_end   <- 1 + lookahead

    for (i in (win_start+1):win_end) {
      id <- bin_id[i]
      if (!is.na(id) && id >= 1) hist[id] <- hist[id] + 1L
    }

    # slide
    last_valid <- n - lookahead

    for (i in 1:last_valid) {

      s <- sum(hist)
      if (s > 0L) {
        p <- hist / s
        ent <- -sum(p * log(p + eps))
        r_T <- (future_max[i] / close[i]) - 1
        ES[i] <- r_T / ((sigma_path[i] + eps) * (1 + ent))
      }

      # remove old
      old_id <- bin_id[i+1]
      if (!is.na(old_id) && old_id >= 1) hist[old_id] <- hist[old_id] - 1L

      # add new
      new_id <- bin_id[i + lookahead + 1]
      if (!is.na(new_id) && new_id >= 1) hist[new_id] <- hist[new_id] + 1L
    }

    ES
  }, by = symbol]

  invisible(dt)
}

#' Extreme high identity forward feature
#'
#' Calculates ratio of maximum future high to current close.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_extreme_high_identity <- function(dt, lookahead) {
  dt[, extreme_high_identity := future_max / close]
  invisible(dt)
}

#' Extreme low identity forward feature
#'
#' Calculates ratio of minimum future low to current close.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_extreme_low_identity <- function(dt, lookahead) {
  dt[, extreme_low_identity := future_min / close]
  invisible(dt)
}

#' Extreme high log forward feature
#'
#' Log transform of extreme_high_identity.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_extreme_high_log <- function(dt, lookahead) {
  dt[, extreme_high_log := {
    log(extreme_high_identity)
  }, by = symbol]
  invisible(dt)
}

#' Extreme low log forward feature
#'
#' Log transform of extreme_low_identity.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_extreme_low_log <- function(dt, lookahead) {
  dt[, extreme_low_log := {
    log(extreme_low_identity)
  }, by = symbol]
  invisible(dt)
}

#' Mass high forward feature
#'
#' Calculates cumulative sum of future highs relative to close.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_mass_high <- function(dt, lookahead) {
  dt[, mass_high := future_sum_high / close - lookahead]
  invisible(dt)
}

#' Mass low forward feature
#'
#' Calculates cumulative sum of future lows relative to close.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_mass_low <- function(dt, lookahead) {
  dt[, mass_low := future_sum_low / close - lookahead]
  invisible(dt)
}

#' Differential extreme identity forward feature
#'
#' Calculates sum of normalized max high and min low deviations.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_de <- function(dt, lookahead) {
  dt[, de := future_max / open + future_min / open - 2]
  invisible(dt)
}

#' Differential mass identity forward feature
#'
#' Calculates difference between cumulative high and low deviations.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_dm <- function(dt, lookahead) {
  dt[, dm := future_sum_high_norm - future_sum_low_norm]
  invisible(dt)
}

#' Skewness forward feature
#'
#' Calculates rolling skewness of future returns over the lookahead window.
#' Positive skewness indicates right tail (potential for large gains),
#' negative skewness indicates left tail (potential for large losses).
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_skewness <- function(dt, lookahead) {
  dt[, skewness := {
    # Vectorized rolling skewness calculation
    # Skewness = E[((X - μ) / σ)³]
    
    # Rolling mean and standard deviation
    mu <- frollmean(future_rets, n = lookahead, align = "left", na.rm = TRUE)
    sigma <- frollsd(future_rets, n = lookahead, align = "left", na.rm = TRUE)
    
    # Standardized values cubed: ((X - μ) / σ)³
    z_cubed <- ((future_rets - mu) / sigma)^3
    
    # Rolling mean of cubed standardized values = skewness
    frollmean(z_cubed, n = lookahead, align = "left", na.rm = TRUE)
  }, by = symbol]
  
  invisible(dt)
}

#' MA short ratio forward feature
#'
#' Calculates ratio of signal to short moving averages.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @param params List containing signal and short MA periods
#' @return Modified data.table (invisible)
apply_fwd_ma_short_ratio <- function(dt, lookahead, params) {
  dt[, ma_short_ratio := conform(future_ma_signal / future_ma_short)]
  invisible(dt)
}

#' MA long ratio forward feature
#'
#' Calculates ratio of short to long moving averages.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @param params List containing short and long MA periods
#' @return Modified data.table (invisible)
apply_fwd_ma_long_ratio <- function(dt, lookahead, params) {
  dt[, ma_long_ratio := future_ma_signal / future_ma_long]
  invisible(dt)
}

#' MA macro ratio forward feature
#'
#' Calculates ratio of long to macro moving averages.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @param params List containing long and macro MA periods
#' @return Modified data.table (invisible)
apply_fwd_ma_macro_ratio <- function(dt, lookahead, params) {
  dt[, ma_macro_ratio := future_ma_signal / future_ma_macro]
  invisible(dt)
}

#' Close identity forward feature
#'
#' Calculates future close return relative to current open.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_close_identity <- function(dt, lookahead) {
  dt[, close_identity := {
    future_close <- data.table::shift(close, n = lookahead, type = "lead")
    future_close / open - 1
  }, by = symbol]
  invisible(dt)
}

#' Close log forward feature
#'
#' Log return of future close relative to current open.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_close_log <- function(dt, lookahead) {
  dt[, close_log := {
    future_close <- data.table::shift(close, n = lookahead, type = "lead")
    log(future_close / open)
  }, by = symbol]
  invisible(dt)
}
