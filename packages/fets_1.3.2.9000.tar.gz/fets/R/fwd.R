#' Forward-looking feature calculation
#'
#' Calculates forward-looking technical indicators for financial time series data.
#'
#' @param dtbl A data.table with columns: symbol, date, open, high, low, close
#' @param methods Character vector of methods to apply (default: all available methods)
#' @param lookahead Integer number of periods to look ahead (default: 15)
#' @param drop Logical, drop OHLC columns except close (default: TRUE)
#' @param inplace Logical, modify data.table in place (default: FALSE)
#' @param time Logical, print elapsed time (default: TRUE)
#' @return Modified data.table with forward-looking features
#' @export
fwd <- function(
  dtbl,
  methods = fwd_methods(),
  lookahead = 15,
  params = list(
    signal = 5,
    short = 12,
    long = 28,
    macro = 80
  ),
  drop = TRUE,
  inplace = FALSE,
  time = TRUE
) {
  if (!is.data.table(dtbl)) {
    stop("Input dt must be a data.table")
  }
  if (length(setdiff(c("symbol", "date", "open", "high", "low", "close"), names(dtbl))) > 0) {
    stop("Data table must contain 'symbol', 'date', 'open', 'high', 'low', and 'close' columns.")
  }

  start_time <- Sys.time()

  # Edit in place or create a copy
  dt <- if (inplace) { dtbl } else { data.table::copy(dtbl) }

  # Ensure parameters
  params$signal <- params$signal %||% 5
  params$short <- params$short %||% 12
  params$long <- params$long %||% 28
  params$macro <- params$macro %||% 80

  # Calculate methods for each symbol
  for (method in methods) {
    apply_fwd(dt, method, lookahead, params)
  }

  if (drop) {
    dt[, c("open", "high", "low") := NULL]
  }

  if (time) {
    end_time <- Sys.time()
    elapsed <- as.numeric(difftime(end_time, start_time, units = "secs"))
    message(sprintf("fwd completed in %f seconds", elapsed))
  }

  dt
}

#' Available forward-looking methods
#'
#' Returns a character vector of all available forward-looking calculation methods.
#'
#' @return Character vector of method names
#' @export
fwd_methods <- function() {
  c(
    # Extreme (max high, min low) methods
    "extreme_high_identity",
    "extreme_high_log",
    "extreme_low_identity",
    "extreme_low_log",
    # Mass (sum, integral) methods
    "mass_high_identity",
    "mass_low_identity",
    # Mean methods
    "mean_identity",
    "mean_log",
    # Differential extreme (de) methods
    "de_identity",
    "de_log",
    # Differential mass (dm) methods
    "dm_identity",
    "dm_log",
    # Sharpe methods
    "sharpe_high",
    "sharpe_low",
    # Moving averages
    "ma_short_ratio",
    "ma_long_ratio",
    "ma_macro_ratio",
    # Last methods
    "close_identity",
    "close_log"
  )
}

#' Apply forward-looking method
#'
#' Dispatches to specific forward-looking calculation method.
#'
#' @param dt Data.table with OHLC data
#' @param method Character string specifying the method
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd <- function(dt, method, lookahead, params) {
  # Extreme (max high, min low) methods
  if (method == "extreme_high_identity") {
    apply_fwd_extreme_high_identity(dt, lookahead)
  } else if (method == "extreme_high_log") {
    apply_fwd_extreme_high_log(dt, lookahead)
  } else if (method == "extreme_low_identity") {
    apply_fwd_extreme_low_identity(dt, lookahead)
  } else if (method == "extreme_low_log") {
    apply_fwd_extreme_low_log(dt, lookahead)
  } else
  # Mass (sum, integral) methods
  if (method == "mass_high_identity") {
    apply_fwd_mass_high_identity(dt, lookahead)
  } else if (method == "mass_low_identity") {
    apply_fwd_mass_low_identity(dt, lookahead)
  } else
  # Mean methods
  if (method == "mean_identity") {
    apply_fwd_mean_identity(dt, lookahead)
  } else if (method == "mean_log") {
    apply_fwd_mean_log(dt, lookahead)
  } else
  # Differential extreme (de) methods
  if (method == "de_identity") {
    apply_fwd_de_identity(dt, lookahead)
  } else if (method == "de_log") {
    apply_fwd_de_log(dt, lookahead)
  } else
  # Differential mass (dm) methods
  if (method == "dm_identity") {
    apply_fwd_dm_identity(dt, lookahead)
  } else if (method == "dm_log") {
    apply_fwd_dm_log(dt, lookahead)
  } else
  # Sharpe methods
  if (method == "sharpe_high") {
    apply_fwd_sharpe_high(dt, lookahead)
  } else if (method == "sharpe_low") {
    apply_fwd_sharpe_low(dt, lookahead)
  } else
  # Moving averages
  if (method == "ma_short_ratio") {
    apply_fwd_ma_short_ratio(dt, lookahead, params)
  } else if (method == "ma_long_ratio") {
    apply_fwd_ma_long_ratio(dt, lookahead, params)
  } else if (method == "ma_macro_ratio") {
    apply_fwd_ma_macro_ratio(dt, lookahead, params)
  } else
  # Last methods
  if (method == "close_identity") {
    apply_fwd_close_identity(dt, lookahead)
  } else if (method == "close_log") {
    apply_fwd_close_log(dt, lookahead)
  } else {
  # Unrecognised method
    stop(sprintf("Unknown method: %s", method))
  }

  invisible(dt)
}

#' Extreme high identity forward feature
#'
#' Calculates ratio of maximum future high to current close.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_extreme_high_identity <- function(dt, lookahead) {
  dt[, extreme_high_identity := {
    future_high <- data.table::shift(high, n = 1, type = "lead")
    future_max <- frollmax(future_high, n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_max / close
  }, by = symbol]
  invisible(dt)
}

#' Extreme low identity forward feature
#'
#' Calculates ratio of minimum future low to current close.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_extreme_low_identity <- function(dt, lookahead) {
  dt[, extreme_low_identity := {
    future_low <- data.table::shift(low, n = 1, type = "lead")
    future_min <- frollmin(future_low, n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_min / close
  }, by = symbol]
  invisible(dt)
}

#' Extreme high log forward feature
#'
#' Log transform of extreme_high_identity.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_extreme_high_log <- function(dt, lookahead) {
  dt[, extreme_high_log := {
    log(extreme_high_identity)
  }, by = symbol]
  invisible(dt)
}

#' Extreme low log forward feature
#'
#' Log transform of extreme_low_identity.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_extreme_low_log <- function(dt, lookahead) {
  dt[, extreme_low_log := {
    log(extreme_low_identity)
  }, by = symbol]
  invisible(dt)
}

#' Mass high identity forward feature
#'
#' Calculates cumulative sum of future highs relative to close.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_mass_high_identity <- function(dt, lookahead) {
  dt[, mass_high_identity := {
    future_high <- data.table::shift(high, n = 1, type = "lead")
    future_sum <- frollsum(future_high, n = lookahead, align = "left", na.rm = TRUE)
    future_sum / close - lookahead
  }, by = symbol]
  invisible(dt)
}

#' Mass low identity forward feature
#'
#' Calculates cumulative sum of future lows relative to close.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_mass_low_identity <- function(dt, lookahead) {
  dt[, mass_low_identity := {
    future_low <- data.table::shift(low, n = 1, type = "lead")
    future_sum <- frollsum(future_low, n = lookahead, align = "left", na.rm = TRUE)
    future_sum / close - lookahead
  }, by = symbol]
  invisible(dt)
}

#' Mean identity forward feature
#'
#' Calculates mean of future midpoint prices relative to open.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_mean_identity <- function(dt, lookahead) {
  dt[, mean_identity := {
    future_high <- data.table::shift(high, n = 1, type = "lead")
    future_low <- data.table::shift(low, n = 1, type = "lead")
    future_midpoint <- (future_high + future_low) / 2
    future_mean <- frollmean(future_midpoint, n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_mean / open
  }, by = symbol]
  invisible(dt)
}

#' Mean log forward feature
#'
#' Log transform of mean_identity.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_mean_log <- function(dt, lookahead) {
  dt[, mean_log := {
    log(mean_identity)
  }, by = symbol]
  invisible(dt)
}

#' Differential extreme identity forward feature
#'
#' Calculates sum of normalized max high and min low deviations.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_de_identity <- function(dt, lookahead) {
  dt[, de_identity := {
    future_high <- data.table::shift(high, n = 1, type = "lead")
    future_low <- data.table::shift(low, n = 1, type = "lead")
    future_max_high <- frollmax(future_high, n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_min_low <- frollmin(future_low, n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_max_high / open + future_min_low / open - 2
  }, by = symbol]
  invisible(dt)
}

#' Differential extreme log forward feature
#'
#' Log-space version of differential extreme calculation.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_de_log <- function(dt, lookahead) {
  dt[, de_log := {
    future_high <- data.table::shift(high, n = 1, type = "lead")
    future_low <- data.table::shift(low, n = 1, type = "lead")
    future_max_high <- frollmax(future_high, n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_min_low <- frollmin(future_low, n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    log(future_max_high) + log(future_min_low) - 2 * log(open)
  }, by = symbol]
  invisible(dt)
}

#' Differential mass identity forward feature
#'
#' Calculates difference between cumulative high and low deviations.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_dm_identity <- function(dt, lookahead) {
  dt[, dm_identity := {
    future_high <- data.table::shift(high, n = 1, type = "lead")
    future_low <- data.table::shift(low, n = 1, type = "lead")
    future_sum_high <- frollsum(future_high / open - 1, n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_sum_low <- frollsum(1 - future_low / open, n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_sum_high - future_sum_low
  }, by = symbol]
  invisible(dt)
}

#' Differential mass log forward feature
#'
#' Log-space version of differential mass calculation.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_dm_log <- function(dt, lookahead) {
  dt[, dm_log := {
    future_high <- data.table::shift(high, n = 1, type = "lead")
    future_low <- data.table::shift(low, n = 1, type = "lead")
    future_sum <- frollsum(log(future_high / open) + log(future_low / open), n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_sum
  }, by = symbol]
  invisible(dt)
}

#' Sharpe high forward feature
#'
#' Calculates risk-adjusted return measure for highs.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_sharpe_high <- function(dt, lookahead) {
  dt[, sharpe_high := {
    future_high <- data.table::shift(high, n = 1, type = "lead")
    future_low <- data.table::shift(low, n = 1, type = "lead")
    future_mean_high <- frollmean(future_high / open - 1, n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_sd_ratio <- frollapply(future_high / future_low - 1, N = lookahead, align = "left", FUN = sd, na.rm = TRUE)
    ifelse(future_sd_ratio == 0, NA_real_, future_mean_high / future_sd_ratio)
  }, by = symbol]
  invisible(dt)
}

#' Sharpe low forward feature
#'
#' Calculates risk-adjusted return measure for lows.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_sharpe_low <- function(dt, lookahead) {
  dt[, sharpe_low := {
    future_high <- data.table::shift(high, n = 1, type = "lead")
    future_low <- data.table::shift(low, n = 1, type = "lead")
    future_mean_low <- frollmean(future_low / open - 1, n = lookahead, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_sd_ratio <- frollapply(future_high / future_low - 1, N = lookahead, align = "left", FUN = sd, na.rm = TRUE)
    ifelse(future_sd_ratio == 0, NA_real_, future_mean_low / future_sd_ratio)
  }, by = symbol]
  invisible(dt)
}

#' MA short ratio forward feature
#'
#' Calculates ratio of signal to short moving averages.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @param params List containing signal and short MA periods
#' @return Modified data.table (invisible)
apply_fwd_ma_short_ratio <- function(dt, lookahead, params) {
  dt[, ma_short_ratio := {
    future_close <- data.table::shift(close, n = lookahead, type = "lead")
    future_ma_signal <- frollmean(future_close, n = params$signal, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_ma_short <- frollmean(future_close, n = params$short, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_ma_signal / future_ma_short
  }, by = symbol]
  invisible(dt)
}

#' MA long ratio forward feature
#'
#' Calculates ratio of short to long moving averages.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @param params List containing short and long MA periods
#' @return Modified data.table (invisible)
apply_fwd_ma_long_ratio <- function(dt, lookahead, params) {
  dt[, ma_long_ratio := {
    future_close <- data.table::shift(close, n = lookahead, type = "lead")
    # future_ma_short <- frollmean(future_close, n = params$short, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_ma_signal <- frollmean(future_close, n = params$signal, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_ma_long <- frollmean(future_close, n = params$long, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_ma_signal / future_ma_long
  }, by = symbol]
  invisible(dt)
}

#' MA macro ratio forward feature
#'
#' Calculates ratio of long to macro moving averages.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @param params List containing long and macro MA periods
#' @return Modified data.table (invisible)
apply_fwd_ma_macro_ratio <- function(dt, lookahead, params) {
  dt[, ma_macro_ratio := {
    future_close <- data.table::shift(close, n = lookahead, type = "lead")
    # future_ma_long <- frollmean(future_close, n = params$long, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_ma_signal <- frollmean(future_close, n = params$signal, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_ma_macro <- frollmean(future_close, n = params$macro, align = "left", na.rm = TRUE, adaptive = FALSE)
    future_ma_signal / future_ma_macro
  }, by = symbol]
  invisible(dt)
}

#' Close identity forward feature
#'
#' Calculates future close return relative to current open.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_close_identity <- function(dt, lookahead) {
  dt[, close_identity := {
    future_close <- data.table::shift(close, n = lookahead, type = "lead")
    future_close / open - 1
  }, by = symbol]
  invisible(dt)
}

#' Close log forward feature
#'
#' Log return of future close relative to current open.
#'
#' @param dt Data.table with OHLC data
#' @param lookahead Integer number of periods to look ahead
#' @return Modified data.table (invisible)
apply_fwd_close_log <- function(dt, lookahead) {
  dt[, close_log := {
    future_close <- data.table::shift(close, n = lookahead, type = "lead")
    log(future_close / open)
  }, by = symbol]
  invisible(dt)
}
